<?php

require 'vendor/autoload.php';

use MongoDB\Client as MongoDBClient;
use Predis\Client as RedisClient;

function getRelationalData($pdo) {
    $stmt = $pdo->query("SELECT c.nome AS cliente_nome, com.produto, com.valor
                         FROM Cliente c
                         JOIN Compras com ON c.id = com.id_cliente");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getDocumentData($mongoDb) {
    $collection = $mongoDb->Pessoa;
    return $collection->find()->toArray();
}

function updateRedis($redis, $data) {
    $redis->flushall();
    foreach ($data as $item) {
        $key = "recomendacao:" . $item['cliente_nome'];
        $value = json_encode($item);
        echo "Storing in Redis: $key => $value\n"; // Depuração
        $redis->lpush($key, $value); // Alteração: Usando lpush para inserir na lista
    }
}

try {
    // Conexão com MySQL
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=recomendacao_compras', 'raulan', '21061992');

    // Conexão com MongoDB
    $mongoClient = new MongoDBClient('mongodb://localhost:27017');
    $mongoDb = $mongoClient->recomendacao_compras;

    // Conexão com Redis
    $redis = new RedisClient();

    // Recupera dados do MySQL e MongoDB
    $relationalData = getRelationalData($pdo);
    $documentData = getDocumentData($mongoDb);

    // Combina os dados
    $combinedData = [];
    foreach ($relationalData as $relItem) {
        foreach ($documentData as $docItem) {
            if ($relItem['cliente_nome'] === $docItem['nome']) {
                foreach ($docItem['amigos'] as $amigo) {
                    // Vamos buscar o nome do amigo usando o objectID
                    foreach ($documentData as $amigoDoc) {
                        if ($amigoDoc['objectID'] == $amigo) {
                            $combinedData[] = [
                                'cliente_nome' => $relItem['cliente_nome'],
                                'amigo_nome' => $amigoDoc['nome'], // Nome do amigo
                                'produto' => $relItem['produto'],
                                'valor' => $relItem['valor']
                            ];
                        }
                    }
                }
            }
        }
    }

    // Atualiza o Redis
    updateRedis($redis, $combinedData);

    //echo "Dados atualizados com sucesso no Redis.";

} catch (Exception $e) {
    echo "Erro: " . $e->getMessage();
}
?>
