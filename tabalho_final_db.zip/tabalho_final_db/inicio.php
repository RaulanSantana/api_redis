<?php
session_start();
include_once('conexao.php');
$message = "";
$total = 0;

// Função para buscar os detalhes do produto no banco de dados
function buscarDetalhesProduto($codigo) {
    global $conexao;
    // Query para buscar o produto no banco de dados
    $query = "SELECT * FROM produtos WHERE codigo = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $resultado = $stmt->get_result();
    if ($resultado->num_rows > 0) {
        $produto = $resultado->fetch_assoc();
        return $produto;
    } else {
        return false;
    }
}

// Função para gerar um código aleatório
function gerarCodigoAleatorio() {
    return substr(md5(uniqid(mt_rand(), true)), 0, 8);
}

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se o botão de busca foi clicado
    if (isset($_POST["buscar"])) {
        $codigo = $_POST["produto"];
        // Busca os detalhes do produto no banco de dados
        $produto = buscarDetalhesProduto($codigo);
        if ($produto) {
            $nomeProduto = $produto["nome"];
            $preco = $produto["preco"];
            $descricaoProduto = $produto["descricao_produto"];
            $estoque = $produto['quantidade_estoque'];
        } else {
            $message = "Produto não encontrado.";
        }
    }
    // Verifica se o botão de adicionar ao carrinho foi clicado
    elseif (isset($_POST["adicionarproduto"])) {
        $codigo = $_POST["codigo"];
        $nomeProduto = $_POST["nome"];
        $preco = $_POST["preco"];
        $descricaoProduto = $_POST["descricaoProduto"];
        $quantidade = $_POST["quantidade"];
        $estoque = isset($_POST["estoque"]) ? $_POST["estoque"] : 0; // Define $estoque como 0 se não estiver definido

        // Verifica se o produto já está no carrinho
        $produtoJaNoCarrinho = false;
        if (isset($_SESSION['carrinho'])) {
            foreach ($_SESSION['carrinho'] as &$produto_carrinho) {
                if ($produto_carrinho['codigo'] === $codigo) {
                    $produto_carrinho['quantidade'] += $quantidade;
                    $produtoJaNoCarrinho = true;
                    break;
                }
            }
        } else {
            $_SESSION['carrinho'] = array();
        }

        // Adiciona o produto ao carrinho se ainda não estiver nele
        if (!$produtoJaNoCarrinho) {
            $_SESSION['carrinho'][] = array(
                'codigo' => $codigo,
                'nome' => $nomeProduto,
                'preco' => $preco,
                'descricaoProduto' => $descricaoProduto,
                'quantidade' => $quantidade,
                'estoque' => $estoque
            );
        }
    }
    // Verifica se o botão de buscar cliente foi clicado
    elseif (isset($_POST["buscar_cliente"])) {
        if(isset($_POST["cpf"])) {
            $cpf = $_POST["cpf"];
            // Busca os detalhes do cliente no banco de dados
            $query = "SELECT id, nome, endereco FROM cliente WHERE cpf = ?";
            $stmt = $conexao->prepare($query);
            $stmt->bind_param("s", $cpf);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $cliente = $resultado->fetch_assoc();
                $_SESSION['cliente'] = $cliente;
                $nomeCliente = $cliente["nome"];
                $enderecoCliente = $cliente["endereco"];
            } else {
                $message = "Cliente não encontrado.";
            }
        } else {
            $message = "Por favor, insira um CPF válido.";
        }
    }
    // Verifica se o botão de finalizar venda foi clicado
    elseif (isset($_POST["finalizar_venda"])) {
        if (isset($_SESSION['cliente'])) {
            $id_cliente = $_SESSION['cliente']['id'];
            $total_compra = $total; // Supondo que $total contenha o valor total da compra

            // Inicia uma transação
            $conexao->begin_transaction();

            // Insira os dados da venda no banco de dados
            $query_venda = "INSERT INTO compras (codigo, produto, valor, data, id_cliente) VALUES (?, ?, ?, ?, ?)";
            $stmt_venda = $conexao->prepare($query_venda);

            // Percorre os produtos no carrinho
            foreach ($_SESSION['carrinho'] as $produto_carrinho) {
                $codigo_produto = $produto_carrinho['codigo'];
                $nome_produto = $produto_carrinho['nome'];
                $valor_produto = $produto_carrinho['preco'] * $produto_carrinho['quantidade'];
                $data_atual = date("Y-m-d");

                // Insere a venda no banco de dados
                $stmt_venda->bind_param("ssdsi", $codigo_produto, $nome_produto, $valor_produto, $data_atual, $id_cliente);
                $stmt_venda->execute();

                // Atualiza a quantidade em estoque do produto
                $query_atualizar_estoque = "UPDATE produtos SET quantidade_estoque = quantidade_estoque - ? WHERE codigo = ?";
                $stmt_atualizar_estoque = $conexao->prepare($query_atualizar_estoque);
                $stmt_atualizar_estoque->bind_param("is", $quantidade_vendida, $codigo_produto);

                $quantidade_vendida = $produto_carrinho['quantidade'];
                $stmt_atualizar_estoque->execute();
            }

            // Confirma a transação
            $conexao->commit();

            // Verifica se a consulta foi executada com sucesso
            if ($stmt_venda->affected_rows > 0) {
                $message = "Venda finalizada com sucesso!";
                // Limpe o carrinho
                unset($_SESSION['carrinho']);
            } else {
                $message = "Erro ao finalizar a venda.";
            }

            // Feche as instruções preparadas
            $stmt_venda->close();
            $stmt_atualizar_estoque->close();
        } else {
            $message = "Por favor, digite o cpf antes de finalizar a venda.";
        }
    }
    // Verifica se o botão de limpar carrinho foi clicado
    elseif (isset($_POST["limpar_carrinho"])) {
        unset($_SESSION['carrinho']);
        $message = "Carrinho limpo com sucesso.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Vendas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header class="bg-primary text-white text-center py-3">
    <h1>Sistema de Vendas</h1>
</header>

<main class="container mt-4">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h2>Área de Venda</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="mb-3">
                            <label for="produto" class="form-label">Produto:</label>
                            <input type="text" name="produto" id="produto" class="form-control">
                        </div>
                        <button type="submit" name="buscar" class="btn btn-primary">Buscar</button>
                    </form>
                    <?php if (isset($nomeProduto) && !empty($nomeProduto)) { ?>
                        <hr>
                        <p><strong>Nome:</strong> <?php echo $nomeProduto; ?></p>
                        <p><strong>Preço:</strong> R$ <?php echo $preco; ?></p>
                        <p><strong>Descrição:</strong> <?php echo $descricaoProduto; ?></p>
                        <p><strong>Estoque:</strong> <?php echo $estoque; ?></p>

                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <input type="hidden" name="codigo" value="<?php echo $codigo; ?>">
                            <input type="hidden" name="nome" value="<?php echo $nomeProduto; ?>">
                            <input type="hidden" name="preco" value="<?php echo $preco; ?>">
                            <input type="hidden" name="descricaoProduto" value="<?php echo $descricaoProduto; ?>">
                            <input type="hidden" name="estoque" value="<?php echo $estoque; ?>">
                            <div class="mb-3">
                                <label for="quantidade" class="form-label">Quantidade:</label>
                                <input type="number" name="quantidade" id="quantidade" class="form-control" value="1" min="1" max="<?php echo $estoque; ?>">
                            </div>
                            <button type="submit" name="adicionarproduto" class="btn btn-success w-100">Adicionar ao Carrinho</button>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h2>Carrinho de Compras</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="mb-3">
                            <label for="cpf" class="form-label">CPF:</label>
                            <input type="text" name="cpf" class="form-control">
                        </div>
                        <button type="submit" name="buscar_cliente" class="btn btn-info mb-3">IR</button>
                        <div class="mb-3">
                            <label for="cliente" class="form-label">Cliente:</label>
                            <input type="text" name="cliente" class="form-control" value="<?php echo isset($_SESSION['cliente']['nome']) ? $_SESSION['cliente']['nome'] : ''; ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="endereco" class="form-label">Endereço:</label>
                            <input type="text" name="endereco" class="form-control" value="<?php echo isset($_SESSION['cliente']['endereco']) ? $_SESSION['cliente']['endereco'] : ''; ?>" readonly>
                        </div>
                        
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Código do Produto</th>
                                    <th>Preço</th>
                                    <th>Quantidade</th>
                                    <th>Valor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                if (isset($_SESSION['carrinho'])) {
                                    foreach ($_SESSION['carrinho'] as $produto_carrinho) {
                                        $codigo_produto = $produto_carrinho['codigo'];
                                        $quantidade = $produto_carrinho['quantidade'];
                                        $detalhes_produto = buscarDetalhesProduto($codigo_produto);
                                        if ($detalhes_produto) {
                                            $valor = $detalhes_produto['preco'] * $quantidade;
                                            $total += $valor;
                                ?>
                                            <tr>
                                                <td><?php echo $detalhes_produto['nome']; ?></td>
                                                <td><?php echo $codigo_produto; ?></td>
                                                <td>R$ <?php echo $detalhes_produto['preco']; ?></td>
                                                <td><?php echo $quantidade; ?></td>
                                                <td>R$ <?php echo (float)$valor; ?></td>
                                            </tr>
                                <?php 
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                        
                        <p class="text-end fw-bold">Total: R$ <?php echo $total; ?></p>
                        
                        <button type="submit" name="finalizar_venda" class="btn btn-primary w-100">FINALIZAR COMPRA</button>
                        <button type="submit" name="limpar_carrinho" class="btn btn-danger w-100 mt-2">LIMPAR CARRINHO</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="messageModalLabel">Mensagem</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo $message; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var message = "<?php echo $message; ?>";
        if (message) {
            var modal = new bootstrap.Modal(document.getElementById('messageModal'));
            modal.show();
        }
    });
</script>



<!-- Modal de confirmação de indicação -->
<div class="modal fade" id="confirmIndicateModal" tabindex="-1" aria-labelledby="confirmIndicateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmIndicateModalLabel">Indicar Produto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Deseja indicar este produto para um amigo?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Não</button>
                <button type="button" class="btn btn-primary" onclick="redirectToIndicate()">Sim</button>
            </div>
        </div>
    </div>
</div>

<script>
    function redirectToIndicate() {
        window.location.href = 'indicar.php';
    }

    document.addEventListener('DOMContentLoaded', function() {
        var message = "<?php echo $message; ?>";
        if (message === "Venda finalizada com sucesso!") {
            var modal = new bootstrap.Modal(document.getElementById('confirmIndicateModal'));
            modal.show();
        }
    });
</script>

</body>
</html>
