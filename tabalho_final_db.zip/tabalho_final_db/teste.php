<?php
require 'vendor/autoload.php';
use Predis\Client as RedisClient;

$redis = new RedisClient();
$keys = $redis->keys('*'); // Lista todas as chaves

if (empty($keys)) {
    echo "Nenhum dado encontrado no Redis.";
} else {
    foreach ($keys as $key) {
        echo "Chave: $key, Valor: " . $redis->get($key) . "<br>";
    }
}
?>