<?php 
$dbname='recomendacao_compras';
$host = '127.0.0.1';
$usuario = 'raulan';
$senha ='21061992';



$conexao = new mysqli($host,$usuario,$senha,$dbname);





?>