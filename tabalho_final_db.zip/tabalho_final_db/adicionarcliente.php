<?php 
require 'vendor/autoload.php';
use MongoDB\Client as MongoDBClient;
use MongoDB\BSON\ObjectId as MongoID;

include_once('conexao.php');
$message = "";

// Função para conectar ao MongoDB
function conectarMongoDB() {
    $cliente = new MongoDBClient('mongodb://localhost:27017');
    return $cliente->recomendacao_compras->Pessoa; // Aqui você precisa mudar para o nome da coleção no seu banco de dados MongoDB
}

function obterProximoObjectID($mongoCollection) {
    $ultimoDocumento = $mongoCollection->findOne([], ['sort' => ['objectID' => -1]]);
    if ($ultimoDocumento && isset($ultimoDocumento['objectID'])) {
        return $ultimoDocumento['objectID'] + 1;
    } else {
        // Se não houver nenhum documento na coleção, começamos com 1
        return 1;
    }
}

if (isset($_POST['cadastrar'])) {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $endereco = $_POST['endereco'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];

    if(!filter_var($email, FILTER_VALIDATE_EMAIL) || tamanhoEmail($email)) {
        $message = "Email inválido";
    } else {
        // Verifica se já existe um documento com o mesmo e-mail no MongoDB
        $mongoCollection = conectarMongoDB();
        $documentoExistente = $mongoCollection->findOne(['email' => $email]);

        if ($documentoExistente) {
            // Se o documento existir, atualize o nome e o CPF
            $atualizacao = ['$set' => ['nome' => $nome, 'cpf' => $cpf]];
            $mongoCollection->updateOne(['email' => $email], $atualizacao);
            $message = "Documento existente atualizado no MongoDB";
        } else {
            // Se o documento não existir, insira um novo documento
            $objectId = new MongoID();
            $proximoObjectID = obterProximoObjectID($mongoCollection);

            $documento = [
                '_id' => $objectId, // Gere um ID único para o MongoDB
                'objectID' => "$proximoObjectID", // Obtenha o próximo objectID e atribua-o ao documento
                'nome' => $nome,
                'cpf' => $cpf,
                'email' => $email,
                'amigos' => [] // Inclua o array de amigos vazio
            ];

            $inserido = $mongoCollection->insertOne($documento);

            if ($inserido->getInsertedCount() > 0) {
                $message = "Novo documento inserido no MongoDB";
            } else {
                $message = "Erro ao inserir o novo documento no MongoDB";
            }
        }

        // Inserir ou atualizar no banco de dados SQL
        $query = "INSERT INTO cliente (cpf, nome, endereco, cidade, uf, email) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE nome = VALUES(nome), cpf = VALUES(cpf), endereco = VALUES(endereco), cidade = VALUES(cidade), uf = VALUES(uf)";
        $stmt = mysqli_prepare($conexao, $query);
        mysqli_stmt_bind_param($stmt, "ssssss", $cpf, $nome, $endereco, $cidade, $estado, $email);

        if (mysqli_stmt_execute($stmt)) {
            $message .= "<br>Dados inseridos ou atualizados no MySQL com sucesso";
        } else {
            $message .= "<br>Erro ao inserir ou atualizar os dados no MySQL: " . mysqli_error($conexao);
        }
    }
}

function tamanhoEmail($email){
    if(strlen($email) <= 10){
        return true;
    } else {
        return false;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="formulario">
            <form action="adicionarcliente.php" method="POST">
                <fieldset>
                    <legend>Cadastro de cliente</legend>
                    <label for="nome" id="nomelabel">Nome:</label>
                    <input type="text" id="nometext" name="nome" class="form-control">
                    
                    <label for="cpf" id="cpflabel">CPF:</label>
                    <input type="text" id="cpftext" name="cpf" class="form-control" maxlength="11">
                    
                    <label for="email" id="emaillabel">Email:</label>
                    <input type="text" id="emailtext" name="email" class="form-control">
                 
                    <label for="cidade" id="cidadelabel">Cidade:</label>
                    <input type="text" id="cidadetext" name="cidade" class="form-control">
                   
                    <label for="estado" id="labelestado">Estado:</label>
                    <input type="text" name="estado" id="estadotext" class="form-control" maxlength="2">
                   
                    <label for="endereco" id="enderecolabel">Endereço:</label>
                    <input type="text" id="enderecotext" name="endereco" class="form-control">
                 <br>
                    <button type="submit" name="cadastrar" class="btn btn-primary">CADASTRAR</button>
                </fieldset>
            </form>
        </div>
    </div>

    <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Mensagem</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo $message; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var message = "<?php echo $message; ?>";
            if (message) {
                $('#messageModal').modal('show');
            }
        });
    </script>
</body>
</html>
