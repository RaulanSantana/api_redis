<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recomendações de Compras</title>
    <!-- Adicionando Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
        }
        h1 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Recomendações de Compras</h1>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Amigo</th>
                    <th>Produto</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require 'vendor/autoload.php';
                use Predis\Client as RedisClient;

                $redis = new RedisClient();
                $keys = $redis->keys('recomendacao:*');

                if (empty($keys)) {
                    echo "<tr><td colspan='4'>Nenhum dado encontrado no Redis.</td></tr>";
                } else {
                    foreach ($keys as $key) {
                        $jsonData = $redis->lrange($key, 0, -1); // Obtém os dados como uma lista de strings JSON
                        foreach ($jsonData as $jsonString) {
                            $data = json_decode($jsonString, true); // Decodifica o JSON em um array associativo
                            if ($data !== null) { // Verifica se a decodificação foi bem-sucedida
                                echo "<tr>
                                        <td>{$data['cliente_nome']}</td>
                                        <td>{$data['amigo_nome']}</td>
                                        <td>{$data['produto']}</td>
                                        <td>{$data['valor']}</td>
                                      </tr>";
                            } else {
                                echo "<tr><td colspan='4'>Erro ao decodificar os dados JSON: $jsonString</td></tr>";
                            }
                        }
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    <!-- Adicionando Bootstrap JS (opcional, se necessário) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
