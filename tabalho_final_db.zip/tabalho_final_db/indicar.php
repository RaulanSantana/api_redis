<?php 
require 'vendor/autoload.php';
use MongoDB\Client as MongoDBClient;
use MongoDB\BSON\ObjectId as MongoID;

function conectarMongoDB() {
    $cliente = new MongoDBClient('mongodb://localhost:27017');
    return $cliente->recomendacao_compras->Pessoa; 
}

function obterProximoObjectID($mongoCollection) {
    $ultimoDocumento = $mongoCollection->findOne([], ['sort' => ['objectID' => -1]]);
    if ($ultimoDocumento && isset($ultimoDocumento['objectID'])) {
        return $ultimoDocumento['objectID'] + 1;
    } else {
        // Se não houver nenhum documento na coleção, começamos com 1
        return 1;
    }
}

if (isset($_POST['enviar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cpfComprador = $_POST['cpf_comprador']; // Assumindo que o CPF do comprador está sendo enviado no formulário

    if(!filter_var($email, FILTER_VALIDATE_EMAIL) || tamanhoEmail($email)) {
        $message = "Email inválido";
    } else {
        $mongoCollection = conectarMongoDB();
        $documentoExistente = $mongoCollection->findOne(['email' => $email]);

        // Buscar o objectID do comprador pelo CPF
        $comprador = $mongoCollection->findOne(['cpf' => $cpfComprador]);
        if ($comprador) {
            $meuObjectID = $comprador['objectID'];
        } else {
            $message = "CPF do comprador não encontrado.";
            $meuObjectID = null;
        }

        if ($documentoExistente) {
            // Se o documento existir, adicione o objectID de quem fez a compra no amigos, de quem estou indicando com email.
            if ($meuObjectID) {
                $mongoCollection->updateOne(
                    ['email' => $email],
                    ['$addToSet' => ['amigos' => $meuObjectID]]
                );
                $message = "Você indicou com sucesso!";
            } else {
                $message = "Erro ao adicionar o amigo: objectID do comprador não encontrado.";
            }
        } else {
            // Se o documento não existir, insira um novo documento
            $objectId = new MongoID();
            $proximoObjectID = obterProximoObjectID($mongoCollection);

            $documento = [
                '_id' => $objectId, // Gere um ID único para o MongoDB
                'objectID' => "$proximoObjectID", // Obtenha o próximo objectID e atribua-o ao documento
                'nome' => $nome,
                'cpf' => "", //gere o cpf vazio
                'email' => $email,
                'amigos' => $meuObjectID ? [$meuObjectID] : [] //aqui inclua o ObjectID de quem está indicando no caso deveria aparecer 1
            ];

            $inserido = $mongoCollection->insertOne($documento);

            if ($inserido->getInsertedCount() > 0) {
                $novoIndicadoID = $documento['objectID']; // Pegar o objectID do novo indicado
                if ($meuObjectID) {
                    // Atualizar o documento do comprador para adicionar o novo indicado na lista de amigos
                    $mongoCollection->updateOne(
                        ['objectID' => $meuObjectID],
                        ['$addToSet' => ['amigos' => "$novoIndicadoID"]]
                    );
                }
                $message = "Novo documento inserido no MongoDB e indicação feita com sucesso!";
                
                // Atualiza o Redis
                require_once 'codigoapi.php';
            } else {
                $message = "Erro ao inserir o novo documento no MongoDB";
            }
        }
    }
}

function tamanhoEmail($email){
    return strlen($email) <= 10;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indicar Produto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <fieldset>
                <legend>Indicar Amigo</legend>
                
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome:</label>
                    <input type="text" id="nometext" name="nome" class="form-control">
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="text" id="emailtext" name="email" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="cpf_comprador" class="form-label">CPF do Comprador:</label>
                    <input type="text" id="cpf_comprador" name="cpf_comprador" class="form-control">
                </div>

                <button type="submit" name="enviar" class="btn btn-primary">ENVIAR</button>
            </fieldset>
        </form>
        <?php if (isset($message)) { ?>
            <div class="alert alert-info mt-3">
                <?php echo $message; ?>
            </div>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
