<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recomendações de Compras</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Recomendações de Compras</h1>
    <?php
    require 'vendor/autoload.php';
    use Predis\Client as RedisClient;

    $redis = new RedisClient();
    $keys = $redis->keys('recomendacao:*');

    if (empty($keys)) {
        echo "<p>Nenhum dado encontrado no Redis.</p>";
    } else {
        echo "<table>";
        echo "<tr><th>Cliente</th><th>Amigo</th><th>Produto</th><th>Valor</th></tr>";
        foreach ($keys as $key) {
            $data = json_decode($redis->get($key), true);
            echo "<tr>";
            echo "<td>{$data['cliente_nome']}</td>";
            echo "<td>{$data['amigo_nome']}</td>";
            echo "<td>{$data['produto']}</td>";
            echo "<td>R$ {$data['valor']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    ?>
</body>
</html>
